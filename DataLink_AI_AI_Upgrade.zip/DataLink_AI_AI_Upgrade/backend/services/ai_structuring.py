"""AI-assisted schema inference for CSV/Excel datasets.

The model proposes a schema from a bounded sample. Pandas applies the
column mapping to every row; the original uploaded file is never modified.
"""
import json
import os
import re
import uuid
from pathlib import Path

import pandas as pd


def _json_safe(value):
    if pd.isna(value):
        return None
    if hasattr(value, "item"):
        value = value.item()
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _fallback_name(name):
    name = re.sub(r"[^a-zA-Z0-9]+", "_", str(name).strip()).strip("_").lower()
    return name or "unnamed_column"


def build_profile(dataframe):
    columns = []
    for name in dataframe.columns:
        series = dataframe[name]
        examples = []
        for value in series.dropna().astype(str).drop_duplicates().head(5).tolist():
            examples.append(value[:180])
        columns.append({
            "original_name": str(name),
            "pandas_dtype": str(series.dtype),
            "missing_count": int(series.isna().sum()),
            "unique_count": int(series.nunique(dropna=True)),
            "sample_values": examples,
        })
    sample = [
        {str(k): _json_safe(v) for k, v in row.items()}
        for row in dataframe.head(8).to_dict(orient="records")
    ]
    return {
        "rows": int(len(dataframe)),
        "columns_count": int(len(dataframe.columns)),
        "columns": columns,
        "sample_records": sample,
    }


def infer_schema(dataframe):
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is not configured. Add it to backend/.env and restart Flask.")

    try:
        from openai import OpenAI
    except ImportError as error:
        raise RuntimeError("The OpenAI package is missing. Run: pip install -r backend/requirements.txt") from error

    profile = build_profile(dataframe)
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    client = OpenAI(api_key=api_key, timeout=60.0, max_retries=1)
    instructions = """You are a careful data-structuring assistant. Infer a useful semantic schema for a messy tabular dataset. Return ONLY valid JSON with this exact shape: {\"dataset_description\": string, \"columns\": [{\"original_name\": string, \"structured_name\": string, \"semantic_type\": string, \"reason\": string}], \"recommendations\": [string], \"cautions\": [string]}. Include every input column exactly once. structured_name must be unique snake_case and must not discard information. semantic_type should be one of identifier, person_name, location, numeric, currency, date, datetime, category, email, phone, rating, free_text, boolean, or unknown. Do not infer values not present in the sample. If date formats or meanings are ambiguous, state that in cautions. Preserve columns even if empty. Keep recommendations concise."""
    response = client.chat.completions.create(
        model=model,
        temperature=0,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": instructions},
            {"role": "user", "content": json.dumps(profile, ensure_ascii=False, default=str)},
        ],
    )
    content = response.choices[0].message.content or "{}"
    result = json.loads(content)
    proposed = result.get("columns", [])
    by_original = {str(item.get("original_name")): item for item in proposed if isinstance(item, dict)}

    # Apply the AI mapping only to known columns. Ensure every output name is unique.
    mapping = {}
    seen = set()
    column_report = []
    for original in dataframe.columns:
        original = str(original)
        item = by_original.get(original, {})
        candidate = _fallback_name(item.get("structured_name") or original)
        base, suffix = candidate, 2
        while candidate in seen:
            candidate = f"{base}_{suffix}"
            suffix += 1
        seen.add(candidate)
        mapping[original] = candidate
        column_report.append({
            "original_name": original,
            "structured_name": candidate,
            "semantic_type": str(item.get("semantic_type") or "unknown"),
            "reason": str(item.get("reason") or "Name normalized by deterministic fallback."),
        })

    structured = dataframe.copy()
    structured.columns = [mapping[str(column)] for column in dataframe.columns]
    output_dir = Path(__file__).resolve().parents[2] / "cleaned"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_name = f"structured_{uuid.uuid4().hex[:12]}.csv"
    output_path = output_dir / output_name
    structured.to_csv(output_path, index=False)

    return {
        "dataset_description": str(result.get("dataset_description") or "Dataset schema inferred from sample values."),
        "columns": column_report,
        "recommendations": [str(x) for x in result.get("recommendations", []) if isinstance(x, (str, int, float))],
        "cautions": [str(x) for x in result.get("cautions", []) if isinstance(x, (str, int, float))],
        "rows": int(len(structured)),
        "columns_count": int(len(structured.columns)),
        "preview": [{str(k): _json_safe(v) for k, v in row.items()} for row in structured.head(10).to_dict(orient="records")],
        "download_filename": output_name,
        "model": model,
    }
