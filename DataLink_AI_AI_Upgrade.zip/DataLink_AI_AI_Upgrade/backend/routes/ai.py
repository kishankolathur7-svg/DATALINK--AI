"""AI endpoints for Data Link AI."""
import os
from flask import Blueprint, jsonify, request, send_from_directory

from database import get_db_connection
from routes.files import UPLOAD_FOLDER, CLEANED_FOLDER, read_dataset, make_json_safe
from services.ai_structuring import infer_schema

ai_bp = Blueprint("ai", __name__, url_prefix="/api/ai")


def _get_user_id():
    value = request.args.get("user_id") or (request.get_json(silent=True) or {}).get("user_id")
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


@ai_bp.route("/files/<int:file_id>/structure", methods=["POST"])
def structure_file(file_id):
    user_id = _get_user_id()
    if user_id is None:
        return jsonify({"success": False, "message": "Valid user ID is required."}), 400

    connection = get_db_connection()
    try:
        file_row = connection.execute(
            "SELECT id, original_name, stored_name, file_type FROM uploaded_files WHERE id = ? AND user_id = ?",
            (file_id, user_id),
        ).fetchone()
    finally:
        connection.close()

    if file_row is None:
        return jsonify({"success": False, "message": "File not found for this user."}), 404

    file_path = os.path.join(UPLOAD_FOLDER, file_row["stored_name"])
    if not os.path.isfile(file_path):
        return jsonify({"success": False, "message": "Uploaded file is missing from storage."}), 404

    try:
        dataframe = read_dataset(file_path, file_row["file_type"])
        if dataframe.empty or len(dataframe.columns) == 0:
            return jsonify({"success": False, "message": "The dataset has no rows or columns to structure."}), 400
        if len(dataframe.columns) > 100:
            return jsonify({"success": False, "message": "AI structuring currently supports up to 100 columns per dataset."}), 400
        result = infer_schema(dataframe)
        result["file"] = {"id": file_row["id"], "name": file_row["original_name"]}
        result["download_url"] = f"/api/ai/download/{result['download_filename']}"
        return jsonify(make_json_safe({"success": True, "result": result}))
    except RuntimeError as error:
        return jsonify({"success": False, "message": str(error)}), 503
    except Exception as error:
        return jsonify({"success": False, "message": "AI structuring failed.", "error": str(error)}), 502


@ai_bp.route("/download/<path:filename>", methods=["GET"])
def download_structured(filename):
    # Generated files use a fixed prefix and safe basename, preventing path traversal.
    if os.path.basename(filename) != filename or not filename.startswith("structured_") or not filename.endswith(".csv"):
        return jsonify({"success": False, "message": "Invalid download filename."}), 400
    if not os.path.isfile(os.path.join(CLEANED_FOLDER, filename)):
        return jsonify({"success": False, "message": "Structured file not found. Run structuring again."}), 404
    return send_from_directory(CLEANED_FOLDER, filename, as_attachment=True, download_name="structured_data.csv")
