# Data Link AI — AI Structuring Upgrade

## What this upgrade adds
- A backend AI endpoint that profiles a CSV/Excel dataset and asks the configured model to infer a semantic schema from a bounded sample.
- AI-proposed standardized snake_case column names, semantic types, reasons, recommendations, and cautions.
- Applies the proposed column-name mapping across every row and saves a new structured CSV. It does not overwrite the original upload or silently rewrite cell values.
- A dashboard panel to run the feature, inspect the mapping and preview, and download the structured CSV.
- Fixes Data Quality UI handling for nested summary metrics and object-shaped recommendations.

## Install
From the project root in Codespaces or a Windows terminal:

```bash
python -m pip install -r backend/requirements.txt
```

Create `backend/.env` (do not commit or share it) with:

```env
OPENAI_API_KEY=your_real_api_key
OPENAI_MODEL=gpt-4o-mini
```

Restart Flask after installing packages and setting the key. Never put the API key in frontend JavaScript.

## Test
1. Start the application the same way you normally do.
2. Log in and upload a CSV or Excel file.
3. Click Analyze.
4. In the AI Data Structuring Engine panel, click **Analyze schema with AI**.
5. Review the proposed mappings, warnings, and preview; download the structured CSV.
6. Verify the original uploaded file is unchanged.

## Limitations to explain honestly
- AI infers schema using column names, statistics, and a small sample. It does not send every row to the AI model.
- This milestone standardizes column names and creates a schema report; it does not automatically rewrite every cell value or guarantee semantic extraction from every free-text cell.
- Ambiguous dates and uncertain meanings are surfaced as cautions for human review.
- An OpenAI API key and network access are required for the AI endpoint. If the key is missing, the dashboard shows a clear setup message.
